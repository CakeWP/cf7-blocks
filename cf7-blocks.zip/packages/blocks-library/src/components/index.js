/**
 * All components should be exported from here.
 */
export { default as WithLabel } from './with-label';
