/**
 * Custom Dependencies
 */
import Placeholder from './placeholder';

function Edit() {
	return <Placeholder />;
}

export default Edit;
