/**
 * Blocks
 */
import './submit';
import './form-template';
import './input-base';
import './acceptance';
import './selection-base';
