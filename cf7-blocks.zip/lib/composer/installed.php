<?php return array(
    'root' => array(
        'pretty_version' => 'dev-main',
        'version' => 'dev-main',
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'reference' => '38a7187c113369ef1c4720157940fecf64cf6eb6',
        'name' => 'cakewp/contact-form-7-blocks',
        'dev' => false,
    ),
    'versions' => array(
        'cakewp/contact-form-7-blocks' => array(
            'pretty_version' => 'dev-main',
            'version' => 'dev-main',
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'reference' => '38a7187c113369ef1c4720157940fecf64cf6eb6',
            'dev_requirement' => false,
        ),
    ),
);
